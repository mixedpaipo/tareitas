Pía Correa Brenni
202273042-0
Se necesita que exista un archivo llamado "problemas.txt" y eso sería.
Se ejecuta usando una termianal de python.
Por otro lado descubrí que la función CUPON si funciona al evaluarla fuera de las expresiones con una expresion matemática escrita de esta manera "CUPON(1200) + 200"
No descubrí como poder solucionar el problema dentro del código